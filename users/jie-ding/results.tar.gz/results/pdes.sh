
../../dist/build/ipc/ipc ICC2009_T.pepa --probe "pde_int_cont_req:start, pde_user_interface:stop" --rate number_pdes=1 --hydra-stage flat-mod
mv ICC2009_T.*DF_RESULTS npdes1

../../dist/build/ipc/ipc ICC2009_T.pepa --probe "PDE1::pde_int_cont_req:start, pde_user_interface:stop" --rate number_pdes=2 --hydra-stage flat-mod
mv ICC2009_T.*DF_RESULTS npdes2

../../dist/build/ipc/ipc ICC2009_T.pepa --probe "PDE1::pde_int_cont_req:start, pde_user_interface:stop" --rate number_pdes=3 --hydra-stage flat-mod
mv ICC2009_T.*DF_RESULTS npdes3

../../dist/build/ipc/ipc ICC2009_T.pepa --probe "PDE1::pde_int_cont_req:start, pde_user_interface:stop" --rate number_pdes=4 --hydra-stage flat-mod
mv ICC2009_T.*DF_RESULTS npdes4

../../dist/build/ipc/ipc ICC2009_T.pepa --probe "PDE1::pde_int_cont_req:start, pde_user_interface:stop" --rate number_pdes=5 --hydra-stage flat-mod
mv ICC2009_T.*DF_RESULTS npdes5

../../dist/build/ipc/ipc ICC2009_T.pepa --probe "PDE1::pde_int_cont_req:start, pde_user_interface:stop" --rate number_pdes=6 --hydra-stage flat-mod
mv ICC2009_T.*DF_RESULTS npdes6

../../dist/build/ipc/ipc ICC2009_T.pepa --probe "PDE1::pde_int_cont_req:start, pde_user_interface:stop" --rate number_pdes=7 --hydra-stage flat-mod
mv ICC2009_T.*DF_RESULTS npdes7

../../dist/build/ipc/ipc ICC2009_T.pepa --probe "PDE1::pde_int_cont_req:start, pde_user_interface:stop" --rate number_pdes=8 --hydra-stage flat-mod
mv ICC2009_T.*DF_RESULTS npdes8

../../dist/build/ipc/ipc ICC2009_T.pepa --probe "PDE1::pde_int_cont_req:start, pde_user_interface:stop" --rate number_pdes=9 --hydra-stage flat-mod
mv ICC2009_T.*DF_RESULTS npdes9

../../dist/build/ipc/ipc ICC2009_T.pepa --probe "PDE1::pde_int_cont_req:start, pde_user_interface:stop" --rate number_pdes=10 --hydra-stage flat-mod
mv ICC2009_T.*DF_RESULTS npdes10


